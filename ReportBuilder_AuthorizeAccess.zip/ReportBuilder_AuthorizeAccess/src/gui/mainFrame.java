package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.prefs.Preferences;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

import controller.Controller;

public class mainFrame extends JFrame {
	private Toolbar toolBar;
	private FormPanel formPanel;
	private TablePanel tablePanel;
	private Controller controller;
	private JFileChooser fileChooser;
	private LoginDialog loginDialog;
	private Preferences prefs;

	public mainFrame() {
		super("Report Builder");

		loginDialog = new LoginDialog(this);
		prefs = Preferences.userRoot().node("db");
		loginDialog.setLoginListener(new LoginListener() {
			public void loginSet(String user, String password, boolean lnk) {
				prefs.put("user", user);
				prefs.put("password", password);
			}

			public void loginEventOccured(LoginEvent e) {
				boolean lnked = e.isLnked();
				if (lnked) {
					loginDialog.setVisible(false);
					setVisible(true);
				} else {
					JOptionPane.showMessageDialog(mainFrame.this, "Passoword or User is not correct!", "Error",
							JOptionPane.ERROR_MESSAGE);


				}
			}
		});

		String user = prefs.get("user", "");
		String password = prefs.get("password", "");
		loginDialog.setDefaults(user, password);
		loginDialog.setVisible(true);

		setLayout(new BorderLayout());
		toolBar = new Toolbar(this);
		formPanel = new FormPanel();
		formPanel.setVisible(false);
		tablePanel = new TablePanel();
		controller = new Controller();

		tablePanel.setData(controller.getDilution());
		tablePanel.setData1(controller.getCalibration());

		tablePanel.setTableListener(new TableListener() {
			public void dilutionRowDeleted(int row) {
				controller.removeDilutionRow(row);
			}

			public void calibrationRowDeleted(int row) {
				controller.removeCalibrationRow(row);
			}

		});

		fileChooser = new JFileChooser();
		fileChooser.addChoosableFileFilter(new CalibrationFileFilter());
		fileChooser.addChoosableFileFilter(new DilutionFileFilter());
		fileChooser.addChoosableFileFilter(new TemplateFileFilter());

		formPanel.setFormListener(new FormListener() {
			public void formEventOcurred(FormEvent e) {
				controller.addDilution(e);
				tablePanel.refresh();
			}

		});

		formPanel.setFormListener1(new FormListener1() {
			public void formEvent1ocurred(FormEvent1 e1) {
				controller.addCalibration(e1);
				tablePanel.refresh();
			}

		});

		toolBar.setOriConcenListener(new OriConcenListener() {
			public void oriConcentrationrSet(double oriConcen) {
				controller.addOriCocentration(oriConcen);
				tablePanel.refresh();
				formPanel.setVisible(true);
			}
		});

		add(formPanel, BorderLayout.WEST);
		add(toolBar, BorderLayout.NORTH);
		add(tablePanel, BorderLayout.CENTER);

		setJMenuBar(creatMenuBar());

		setMinimumSize(new Dimension(900, 700));

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private JMenuBar creatMenuBar() {
		JMenuBar menuBar = new JMenuBar();

		JMenu fileMenu = new JMenu("File");
		JMenuItem saveDataItem = new JMenuItem("Save As...");
		JMenuItem openDataItem = new JMenuItem("Open File...");
		JMenuItem importTemplateItem = new JMenuItem("Import Template...");
		JMenuItem exportTemplateItem = new JMenuItem("Export Template...");
		JMenuItem exitItem = new JMenuItem("Exit");

		fileMenu.add(openDataItem);
		fileMenu.add(saveDataItem);
		fileMenu.add(importTemplateItem);
		fileMenu.add(exportTemplateItem);
		fileMenu.addSeparator();
		fileMenu.add(exitItem);

		JMenu windowMenu = new JMenu("Window");
		JMenu showMenu = new JMenu("Show");

		JCheckBoxMenuItem showFormItem = new JCheckBoxMenuItem("Solvent Form");
		showFormItem.setSelected(false);

		showMenu.add(showFormItem);
		windowMenu.add(showMenu);

		menuBar.add(fileMenu);
		menuBar.add(windowMenu);

		showFormItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				JCheckBoxMenuItem menuItem = (JCheckBoxMenuItem) ev.getSource();

				formPanel.setVisible(menuItem.isSelected());
			}
		});

		openDataItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I, ActionEvent.CTRL_MASK));

		openDataItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (fileChooser.showOpenDialog(mainFrame.this) == JFileChooser.APPROVE_OPTION) {
					try {
						if (Utils.getFileExtension(fileChooser.getSelectedFile().getName()).equals("dil")) {
							controller.loadDilutionFromFile(fileChooser.getSelectedFile());
						} else {
							controller.loadCalibrationFromFile(fileChooser.getSelectedFile());
						}
						tablePanel.refresh();
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(mainFrame.this, "Could not load data from file.", "Error",
								JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});

		saveDataItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (fileChooser.showSaveDialog(mainFrame.this) == JFileChooser.APPROVE_OPTION) {
					try {
						if (Utils.getFileExtension(fileChooser.getSelectedFile().getName()).equals("dil")) {
							controller.saveDilutionToFile(fileChooser.getSelectedFile());
						} else {
							controller.saveCalibrationToFile(fileChooser.getSelectedFile());
						}
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(mainFrame.this, "Could not save data to file.", "Error",
								JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});

		exportTemplateItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (fileChooser.showOpenDialog(mainFrame.this) == JFileChooser.APPROVE_OPTION) {
					try {
						controller.exportDilutionToTemplate(fileChooser.getSelectedFile());
						controller.exportCalibrationToTemplate(fileChooser.getSelectedFile());
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(mainFrame.this, "Could not load data from file.", "Error",
								JOptionPane.ERROR_MESSAGE);
					}

				}
			}

		});

		importTemplateItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (fileChooser.showOpenDialog(mainFrame.this) == JFileChooser.APPROVE_OPTION) {
					try {
						controller.importToTemplate(fileChooser.getSelectedFile(), mainFrame.this);
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(mainFrame.this, "Could not load data from file.", "Error",
								JOptionPane.ERROR_MESSAGE);
					}
					tablePanel.refresh();
				}
			}
		});

		exitItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				int action = JOptionPane.showConfirmDialog(mainFrame.this,
						"Do you really want to exit the application?", "Confirm Exit", JOptionPane.OK_CANCEL_OPTION);

				if (action == JOptionPane.OK_OPTION) {
					System.exit(0);
				}
			}
		});

		return menuBar;
	}

}
