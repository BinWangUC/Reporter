package gui;

import java.util.EventObject;

public class FormEvent extends EventObject {
	
	private String Id;
	private String previousId;
	private double solutionQuantity;
	private String solutionUnit;
	private double solventQuantity;
	private String solventUnit;
	private String combiUnit;
	
	public FormEvent(Object source) {
		super(source);
	}

	public FormEvent(Object source, String Id, String previousId, double solutionQuantity, String solutionUnit,
			double solventQuantity, String solventUnit,String combiUnit) {
		super(source);
		this.Id=Id;
		this.previousId=previousId;
		this.solutionQuantity=solutionQuantity;
		this.solutionUnit = solutionUnit;
		this.solventQuantity = solventQuantity;
		this.solventUnit = solventUnit;
		this.combiUnit = combiUnit;
	}

	
	
	
	public String getSolutionUnit() {
		return solutionUnit;
	}

	public void setSolutionUnit(String solutionUnit) {
		this.solutionUnit = solutionUnit;
	}

	public String getSolventUnit() {
		return solventUnit;
	}

	public void setSolventUnit(String solventUnit) {
		this.solventUnit = solventUnit;
	}

	public String getCombiUnit() {
		return combiUnit;
	}

	public void setCombiUnit(String combiUnit) {
		this.combiUnit = combiUnit;
	}

	public String getId() {
		return Id;
	}

	public void setId(String Id) {
		this.Id = Id;
	}

	public String getPreviousId() {
		return previousId;
	}

	public void setPreviousId(String previousId) {
		this.previousId = previousId;
	}

	public double getSolutionQuantity() {
		return solutionQuantity;
	}

	public void setSolutionQuantity(double solutionQuantity) {
		this.solutionQuantity = solutionQuantity;
	}

	public double getSolventQuantity() {
		return solventQuantity;
	}

	public void setSolventQuantity(double solventQuantity) {
		this.solventQuantity = solventQuantity;
	}

}
