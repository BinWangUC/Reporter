package gui;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import model.Calibration;
import model.Dilution;

public class CalibrationTableModel extends AbstractTableModel {
	
	private List<Calibration> db;
	private String[] colNames= {"Calibrant ID", "Dilution ID", "Solution Quantity", 
			"Solvent Quantity", "Concentration"};
	public CalibrationTableModel() {
		
	}
	
	@Override
	public String getColumnName(int columnn) {
		// TODO Auto-generated method stub
		return colNames[columnn];
	}

	public void setData1(List<Calibration> db) {
		this.db = db;
	}
	
	public int getRowCount() {
		// TODO Auto-generated method stub
		return db.size();
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 5;
	}

	@Override
	public Object getValueAt(int row, int col) {
		Calibration calibration =db.get(row);
		switch(col) {
		case 0:
			return calibration.getCalibrationId();
		case 1:
			return calibration.getDilutionId();
		case 2:
			return calibration.getSolutionQuantity()+" "+calibration.getSolutionUnit();
		case 3:
			return calibration.getSolventQuantity()+" "+calibration.getSolventUnit();
		case 4:
			String cCunit = calibration.getCombiUnit();
			double resultCons;
			double resultCon = calibration.getConcentration();
			if (cCunit.equals("mg/L") || cCunit.equals("ug/mL"))
				resultCons = resultCon * 1000;
			else if (cCunit.equals("ug/L"))
				resultCons = resultCon * 1000000;
			else if (cCunit.equals("g/mL") || cCunit.equals("mg/uL"))
				resultCons = resultCon / 1000000;
			else if (cCunit.equals("g/uL"))
				resultCons = resultCon / 1000000;
			else
				resultCons = resultCon;

			return String.format("%.5f",resultCons) + " " + calibration.getCombiUnit();
		}
		return null;
	}
}
