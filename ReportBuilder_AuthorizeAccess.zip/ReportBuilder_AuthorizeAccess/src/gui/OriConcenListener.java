package gui;

public interface OriConcenListener {
	public void oriConcentrationrSet(double oriConcen);
}
