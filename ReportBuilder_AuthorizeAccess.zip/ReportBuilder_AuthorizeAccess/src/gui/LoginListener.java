package gui;

import java.util.EventListener;

public interface LoginListener extends EventListener {
	public void loginSet(String user, String password, boolean lnk);
	public void loginEventOccured (LoginEvent e);
}
