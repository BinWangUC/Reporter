package gui;

public interface TableListener {
	public void dilutionRowDeleted(int row);
	public void calibrationRowDeleted(int row);
}
