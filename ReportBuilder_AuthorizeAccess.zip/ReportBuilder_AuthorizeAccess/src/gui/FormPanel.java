package gui;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class FormPanel extends JPanel {
	
	private JRadioButton dilutionRadio;
	private JRadioButton calibrationRadio;
	private ButtonGroup choiceRadio;
	private JTextField previousIdField;
	private JTextField idField;
	private JTextField solutionQField;
	private JTextField solventQField;
	private JComboBox solutionQCombo;
	private JComboBox solventQCombo;
	private JComboBox combinationCombo;
	private JButton okBtn;
	private FormListener formListener;
	private FormListener1 formListener1;
	private JLabel idLabel;
	private JLabel preidLabel;
	
	
	public FormPanel() {
		Dimension dim = getPreferredSize();
		dim.width=350;
		setPreferredSize(dim);
		
		// set up choice radio
		dilutionRadio = new JRadioButton("Dilution");
		calibrationRadio = new JRadioButton("Calibration");
		choiceRadio = new ButtonGroup();
		
		idField = new JTextField(8);
		previousIdField = new JTextField(8);
		solutionQField = new JTextField(8);
		solventQField =new JTextField(8);
		okBtn = new JButton("OK");
		
		dilutionRadio.setSelected(true);
		choiceRadio.add(dilutionRadio);
		choiceRadio.add(calibrationRadio);
		
		// set up combobox
        String[] unit1 = { "L", "mL", "uL"};
		solutionQCombo = new JComboBox(unit1);
		solutionQCombo.setSelectedIndex(2);
		
		String[] unit2 = { "L", "mL", "uL"};
		solventQCombo = new JComboBox(unit2);
		solventQCombo.setSelectedIndex(1);
		
		String[] unit3 = { "g/L","mg/L","ug/L","g/mL","mg/mL","ug/mL","g/uL","mg/uL","ug/uL"};
		combinationCombo = new JComboBox(unit3);
		combinationCombo.setSelectedIndex(1);
		
		// set up and update id label
		idLabel= new JLabel("Dilution ID: ");
		preidLabel = new JLabel("Previous Dilution Used: ");
		calibrationRadio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (calibrationRadio.isSelected()) {
					idLabel.setText("Calibrant ID: ");
					preidLabel.setText("Dilution ID: ");
				}
			}
		});
		
		dilutionRadio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(dilutionRadio.isSelected()) {
					idLabel.setText("Dilution ID: ");
					preidLabel.setText("Previous Dilution Used: ");
				}
			}
			
		});
		
		
		okBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Id =idField.getText();
				String previousId = previousIdField.getText();
				double solutionQuantity = Double.parseDouble(solutionQField.getText());
				String solutionUnit =(String)solutionQCombo.getSelectedItem();
				double solventQuantity = Double.parseDouble(solventQField.getText());
				String solventUnit = (String)solventQCombo.getSelectedItem();
				String combiUnit = (String)combinationCombo.getSelectedItem();
				
				if (dilutionRadio.isSelected()){
					FormEvent ev = new FormEvent(this, Id, previousId, solutionQuantity,solutionUnit,solventQuantity,solventUnit,combiUnit);
					if(formListener !=null) {
						formListener.formEventOcurred(ev);
					}
				}
				else {
					FormEvent1 ev = new FormEvent1(this, Id, previousId, solutionQuantity,solutionUnit,solventQuantity,solventUnit,combiUnit);
					if(formListener1 !=null) {
						formListener1.formEvent1ocurred(ev);}
					
				}
			}
			
		});
		
		Border innerBorder=BorderFactory.createTitledBorder("Add New Solvent");
		Border outerBorder=BorderFactory.createEmptyBorder(5,5,5,5);
		setBorder(BorderFactory.createCompoundBorder(outerBorder, innerBorder));
		
		layoutComponents();
	}
	
	public void layoutComponents() {
		setLayout(new GridBagLayout());
		GridBagConstraints gc = new GridBagConstraints();
		
		//////////////// First row //////////////////////////
		gc.gridy=0;
		gc.gridx=0;

		gc.weightx=1;
		gc.weighty=0.1;
		
		gc.anchor=GridBagConstraints.LINE_END;
		add(new JLabel("Dilution or Calibration: "),gc);
		
		gc.gridx=1;
		gc.anchor = GridBagConstraints.LINE_START;
		add(dilutionRadio,gc);
		
		gc.gridx=2;
		gc.anchor= GridBagConstraints.LINE_START;
		add(calibrationRadio,gc);
		
		//////////////// Next row //////////////////////////
		gc.gridy ++;
		
		gc.weightx=1;
		gc.weighty=0.1;
		
		gc.gridx=0;
		gc.anchor=GridBagConstraints.LINE_END;
		add(idLabel,gc);
		
		gc.gridx=1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(idField,gc);		
		
		//////////////// Next row //////////////////////////
		gc.gridy ++;
		
		gc.weightx=1;
		gc.weighty=0.1;
		
		gc.gridx=0;
		gc.anchor=GridBagConstraints.LINE_END;
		add(preidLabel,gc);
		
		gc.gridx=1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(previousIdField,gc);
		
		//////////////// Next row //////////////////////////
		gc.gridy ++;
		
		gc.weightx=1;
		gc.weighty=0.1;
		
		gc.gridx=0;
		gc.anchor=GridBagConstraints.LINE_END;
		add(new JLabel("Solution Quantity:  "),gc);
		
		gc.gridx=1;
		gc.anchor = GridBagConstraints.LINE_START;
		add(solutionQField,gc);
		
		gc.gridx=2;
		gc.anchor = GridBagConstraints.LINE_START;
		add(solutionQCombo,gc);
		
		//////////////// Next row //////////////////////////
		gc.gridy ++;
		
		gc.weightx=1;
		gc.weighty=0.1;
		
		gc.gridx=0;
		gc.anchor=GridBagConstraints.LINE_END;
		add(new JLabel("Solvent Quantity:  "),gc);
		
		gc.gridx=1;
		gc.anchor = GridBagConstraints.LINE_START;
		add(solventQField,gc);
		
		gc.gridx=2;
		gc.anchor = GridBagConstraints.LINE_START;
		add(solventQCombo,gc);
		
		//////////////// Next row //////////////////////////
		gc.gridy ++;
		
		gc.weightx=1;
		gc.weighty=0.1;
		
		gc.gridx=1;
		gc.anchor=GridBagConstraints.LINE_END;
		add(new JLabel("Result Unit:  "),gc);
		
		gc.gridx=2;
		gc.anchor = GridBagConstraints.LINE_START;
		add(combinationCombo,gc);
		
		//////////////// Next row //////////////////////////
		gc.gridy ++;
		
		gc.weightx=1;
		gc.weighty=1;
		
		gc.gridx=1;
		gc.anchor=GridBagConstraints.LINE_START;
		add(okBtn,gc);
	}
	
	public void setFormListener(FormListener listener) {
		this.formListener=listener;
	}
	
	public void setFormListener1(FormListener1 listener1) {
		this.formListener1=listener1;
	}
	
}
