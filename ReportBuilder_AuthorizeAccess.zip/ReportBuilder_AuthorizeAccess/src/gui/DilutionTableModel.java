package gui;
import java.util.List;

import javax.swing.table.AbstractTableModel;
import model.Dilution;

public class DilutionTableModel extends AbstractTableModel {

	private List<Dilution> db;
	private String[] colNames= {"Dilution ID", "Previous Dilution", "Solution Quantity", 
			"Solvent Quantity", "Concentration"};
	public DilutionTableModel() {
		
	}
	
	@Override
	public String getColumnName(int columnn) {
		// TODO Auto-generated method stub
		return colNames[columnn];
	}
	
	public void setData(List<Dilution> db) {
		this.db = db;
	}

	public int getRowCount() {
		// TODO Auto-generated method stub
		return db.size();
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 5;
	}

	@Override
	public Object getValueAt(int row, int col) {
		Dilution dilution =db.get(row);
		switch (col) {
		case 0:
			return dilution.getDilutionId();
		case 1:
			return dilution.getPreviousDilution();
		case 2:
			return dilution.getSolutionQuantity()+" "+dilution.getSolutionUnit();
		case 3:
			return dilution.getSolventQuantity()+" "+dilution.getSolventUnit();
		case 4:
			String cCunit = dilution.getCombiUnit();
			double resultCons;
			double resultCon = dilution.getConcentration();
			if (cCunit.equals("mg/L") || cCunit.equals("ug/mL"))
				resultCons = resultCon * 1000;
			else if (cCunit.equals("ug/L"))
				resultCons = resultCon * 1000000;
			else if (cCunit.equals("g/mL") || cCunit.equals("mg/uL"))
				resultCons = resultCon / 1000000;
			else if (cCunit.equals("g/uL"))
				resultCons = resultCon / 1000000;
			else
				resultCons = resultCon;

			return String.format("%.5f",resultCons) + " " + dilution.getCombiUnit();

		}
		return null;
	}
}
