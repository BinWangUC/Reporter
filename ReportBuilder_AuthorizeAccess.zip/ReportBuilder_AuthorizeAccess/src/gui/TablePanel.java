package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import model.Calibration;
import model.Dilution;

public class TablePanel extends JPanel {
	private JTable dilutionTable;
	private JScrollPane dilutionScroll;
	private DilutionTableModel dilutionTableModel;
	private TableListener tableListener;

	private JTable calibrationTable;
	private JScrollPane calibrationScroll;
	private CalibrationTableModel calibrationTableModel;

	private JPopupMenu popup;

	public TablePanel() {
		dilutionTableModel = new DilutionTableModel();
		dilutionTable = new JTable(dilutionTableModel);
		dilutionScroll = new JScrollPane();

		calibrationTableModel = new CalibrationTableModel();
		calibrationTable = new JTable(calibrationTableModel);
		calibrationScroll = new JScrollPane();

		popup = new JPopupMenu();
		JMenuItem removeItem = new JMenuItem("Delete row");
		JMenuItem reorderCol = new JMenuItem("Reorder Column");
		JMenuItem clearTable = new JMenuItem("Clear Table");
		popup.add(removeItem);
		popup.add(reorderCol);
		popup.add(clearTable);

		// ---------------- delete row in dilution table ----------------//
		dilutionTable.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				int row = dilutionTable.rowAtPoint(e.getPoint());
				dilutionTable.getSelectionModel().setSelectionInterval(row, row);
				if (e.getButton() == MouseEvent.BUTTON3) {
					popup.show(dilutionTable, e.getX(), e.getY());
				}
			}
		});

		calibrationTable.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				int row = calibrationTable.rowAtPoint(e.getPoint());
				calibrationTable.getSelectionModel().setSelectionInterval(row, row);
				if (e.getButton() == MouseEvent.BUTTON3) {
					popup.show(calibrationTable, e.getX(), e.getY());
				}
			}
		});

		removeItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int dilutionRow = dilutionTable.getSelectedRow();
				int calibrationRow = calibrationTable.getSelectedRow();
				if (tableListener != null) {
					if (dilutionTable.isRowSelected(dilutionRow) == true) {
						tableListener.dilutionRowDeleted(dilutionRow);
						dilutionTableModel.fireTableRowsDeleted(dilutionRow, dilutionRow);
					} else {
						tableListener.calibrationRowDeleted(calibrationRow);
						calibrationTableModel.fireTableRowsDeleted(calibrationRow, calibrationRow);
					}

				}
			}
		});

		clearTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int dilutionSize = dilutionTable.getRowCount();
				int calibrationSize = calibrationTable.getRowCount();
				if (tableListener != null) {
					if (dilutionTable.isRowSelected(dilutionTable.getSelectedRow()) == true) {
						for (int i = 0; i <= dilutionSize - 1; i++) {
							tableListener.dilutionRowDeleted(0);
							dilutionTableModel.fireTableRowsDeleted(0, 0);
						}
						
					} else {
						for (int i = 0; i <= calibrationSize - 1; i++) {
							tableListener.calibrationRowDeleted(0);
							calibrationTableModel.fireTableRowsDeleted(0, 0);
						}
					}

				}
			}
		});

		setLayout(new BorderLayout());
		Dimension dim = dilutionScroll.getPreferredSize();
		dim.height = 300;
		dilutionScroll.setPreferredSize(dim);
		dilutionScroll.getViewport().add(dilutionTable);
		dilutionScroll.setBorder(BorderFactory.createTitledBorder("Dilution Table"));
		add(dilutionScroll, BorderLayout.NORTH);

		calibrationScroll.getViewport().add(calibrationTable);
		calibrationScroll.setBorder(BorderFactory.createTitledBorder("Calibration Table"));
		add(calibrationScroll, BorderLayout.CENTER);

	}

	public void setData(List<Dilution> db) {
		dilutionTableModel.setData(db);
	}

	public void setData1(List<Calibration> db) {
		calibrationTableModel.setData1(db);
	}

	public void refresh() {
		dilutionTableModel.fireTableDataChanged();
		calibrationTableModel.fireTableDataChanged();
	}

	public void setTableListener(TableListener listener) {
		this.tableListener = listener;
	}

}
