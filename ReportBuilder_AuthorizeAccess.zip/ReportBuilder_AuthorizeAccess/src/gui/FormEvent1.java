package gui;

import java.util.EventObject;

public class FormEvent1 extends EventObject {
	
	private String calibrantId;
	private String dilutionId;
	private double solutionQuantity;
	private String solutionUnit;
	private double solventQuantity;
	private String solventUnit;
	private String combiUnit;
	
	
	public FormEvent1(Object source) {
		super(source);
	}
	
	public FormEvent1(Object source, String calibrantId, String dilutionId, double solutionQuantity , String solutionUnit,
			double solventQuantity, String solventUnit, String combiUnit) {
		super(source);
		this.calibrantId=calibrantId;
		this.dilutionId=dilutionId;
		this.solutionQuantity=solutionQuantity;
		this.solutionUnit = solutionUnit;
		this.solventQuantity = solventQuantity;
		this.solventUnit = solventUnit;
		this.combiUnit = combiUnit;
	}


	public String getSolutionUnit() {
		return solutionUnit;
	}

	public void setSolutionUnit(String solutionUnit) {
		this.solutionUnit = solutionUnit;
	}

	public String getSolventUnit() {
		return solventUnit;
	}

	public void setSolventUnit(String solventUnit) {
		this.solventUnit = solventUnit;
	}

	public String getCombiUnit() {
		return combiUnit;
	}

	public void setCombiUnit(String combiUnit) {
		this.combiUnit = combiUnit;
	}
	
	
	public String getCalibrantId() {
		return calibrantId;
	}

	public void setCalibrantId(String calibrantId) {
		this.calibrantId = calibrantId;
	}

	public String getDilutionId() {
		return dilutionId;
	}

	public void setDilutionId(String dilutionId) {
		this.dilutionId = dilutionId;
	}

	public double getSolutionQuantity() {
		return solutionQuantity;
	}

	public void setSolutionQuantity(double solutionQuantity) {
		this.solutionQuantity = solutionQuantity;
	}

	public double getSolventQuantity() {
		return solventQuantity;
	}

	public void setSolventQuantity(double solventQuantity) {
		this.solventQuantity = solventQuantity;
	}

}
