package gui;

import java.util.EventObject;

public class LoginEvent extends EventObject{

	private String user;
	private String password;
	private boolean lnked;
	
	public LoginEvent(Object source) {
		super(source);
	}
	
	public LoginEvent (Object source, String user, String password, boolean lnked) {
		super(source);
		this.user = user;
		this.password=password;
		this.lnked = lnked;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isLnked() {
		return lnked;
	}

	public void setLnked(boolean lnked) {
		this.lnked = lnked;
	}
	
	

}
