package gui;

import java.util.EventListener;

public interface FormListener1 extends EventListener {
	
	public void formEvent1ocurred(FormEvent1 e);

}
