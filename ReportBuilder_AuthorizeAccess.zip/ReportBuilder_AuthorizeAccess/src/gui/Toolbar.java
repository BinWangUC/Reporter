package gui;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Toolbar extends JPanel {
	private JButton saveButton;
	private OriConcenListener oriConcenListener;
	
	public Toolbar(JFrame parent) {
		setBorder(BorderFactory.createEtchedBorder());
		saveButton = new JButton("Pick Stock Solution");
		
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String oriConcen = JOptionPane.showInputDialog(parent, "Enter the original concentraion (mg/L).", "Original Solution ID",
						JOptionPane.OK_OPTION | JOptionPane.QUESTION_MESSAGE);
				if (oriConcenListener != null) {
					oriConcenListener.oriConcentrationrSet((Double.valueOf(oriConcen)));
				}
			}
			
		});
		
		setLayout(new FlowLayout(FlowLayout.LEFT));
		
		add(saveButton);
	}
	public void setOriConcenListener(OriConcenListener oriConcenListener) {
		this.oriConcenListener = oriConcenListener;}

}
