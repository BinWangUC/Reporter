package model;

import java.io.Serializable;

public class Calibration implements Serializable{
	private static final long serialVersionUID = -6753962749069600421L;
	
	private String calibrationId;
	private String dilutionId;
	private double solutionQuantity;
	private String solutionUnit;
	private double solventQuantity;
	private String solventUnit;
	private double concentration;
	private String combiUnit;

	public Calibration(String calibrationId, String dilutionId, double solutionQuantity,String solutionUnit, 
			double solventQuantity,String solventUnit, double concentration,String combiUnit) {
		this.calibrationId = calibrationId;
		this.dilutionId= dilutionId;
		this.solutionQuantity= solutionQuantity;
		this.solutionUnit =solutionUnit;
		this.solventQuantity = solventQuantity;
		this.solventUnit = solventUnit;
		this.concentration = concentration;
		this.combiUnit = combiUnit;
		
	}

	public String getSolutionUnit() {
		return solutionUnit;
	}
	public String getSolventUnit() {
		return solventUnit;
	}
	public String getCombiUnit() {
		return combiUnit;
	}
	
	public String getCalibrationId() {
		return calibrationId;
	}

	public void setCalibrationId(String calibrationId) {
		this.calibrationId = calibrationId;
	}

	public String getDilutionId() {
		return dilutionId;
	}

	public void setDilutionId(String dilutionId) {
		this.dilutionId = dilutionId;
	}

	public double getSolutionQuantity() {
		return solutionQuantity;
	}

	public void setSolutionQuantity(double solutionQuantity) {
		this.solutionQuantity = solutionQuantity;
	}

	public double getSolventQuantity() {
		return solventQuantity;
	}

	public void setSolventQuantity(double solventQuantity) {
		this.solventQuantity = solventQuantity;
	}

	public double getConcentration() {
		return concentration;
	}

	public void setConcentration(double concentration) {
		this.concentration = concentration;
	}

}
