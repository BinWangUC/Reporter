package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LinkDatabase {
	private Connection con;
	
	
	public void connect() throws Exception {

		if (con != null)
			return;

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new Exception("Driver not found");
		}

		String url = "jdbc:mysql://localhost:3306/actgal";
		con = DriverManager.getConnection(url, "root", "Wb87544513!");
		System.out.println(con);
	}
	
	public void disconnect() {
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println("Can't close connection");
			}
		}
	}
	
	public boolean authorize(String userInput, String passInput) throws SQLException {
		
		String sql = "select FirstName, LastName, LoginPd from staff order by FirstName";
		System.out.println(con);
		Statement selectStatement = con.createStatement();
		
		ResultSet results = selectStatement.executeQuery(sql);
		
		boolean lnked = false;
		while(results.next()) {
			String firstName = results.getString("First Name");
			String lastName = results.getString("Last Name");
			String password = results.getString("Password");
			
			if (userInput.equals(firstName+" "+lastName) && passInput.contentEquals(password))
				lnked=true;
		}
		
		results.close();
		selectStatement.close();
		return lnked;
		
	}
}
