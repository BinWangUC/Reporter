package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class CalibrationData {
	private List<Calibration> calibrate;

	public CalibrationData() {
		calibrate = new LinkedList<Calibration>();
	}

	public void addCalibration(Calibration calibration) {
		calibrate.add(calibration);
	}

	public List<Calibration> getCalibration() {
		return calibrate;
	}

	public void removeRow(int index) {
		calibrate.remove(index);
	}

	public void saveToTemplate(File file) throws IOException {
		String content = "";
		content = new String ( Files.readAllBytes(file.toPath())) ;

		FileOutputStream fos = new FileOutputStream(file);
		OutputStreamWriter bw = new OutputStreamWriter(fos, "UTF-8");
		// BufferedWriter bw = new BufferedWriter(osw);

		List<Calibration> db = new ArrayList<>(calibrate);

		bw.write(content);
		
		bw.write(Integer.toString(db.size()));
		bw.write(System.getProperty("line.separator"));
		for (int i = 0; i < db.size(); i++) {
			bw.write( db.get(i).getCalibrationId() + "," + db.get(i).getDilutionId() + ","
					+ db.get(i).getSolutionQuantity() + "," + db.get(i).getSolutionUnit() + ","
					+ db.get(i).getSolventQuantity() + "," + db.get(i).getSolventUnit() + ","
					+ db.get(i).getCombiUnit());
			bw.write(System.getProperty("line.separator"));
		}

		bw.close();
		// osw.close();
		fos.close();
	}

	public void saveToFile(File file) throws IOException {
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);

		Calibration[] calibration = calibrate.toArray(new Calibration[calibrate.size()]);

		oos.writeObject(calibration);
		oos.close();
	}

	public void loadFromFile(File file) throws IOException {
		FileInputStream fis = new FileInputStream(file);
		ObjectInputStream ois = new ObjectInputStream(fis);

		try {
			Calibration[] calibration = (Calibration[]) ois.readObject();
			calibrate.clear();
			calibrate.addAll(Arrays.asList(calibration));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ois.close();
	}
}
