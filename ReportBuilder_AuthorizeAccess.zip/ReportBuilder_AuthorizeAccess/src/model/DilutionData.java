package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class DilutionData {
	private List<Dilution> dilute;

	public DilutionData() {
		dilute = new LinkedList<Dilution>();
	}

	public void addDilution(Dilution dilution) {
		dilute.add(dilution);
	}

	public List<Dilution> getDilution() {
		return Collections.unmodifiableList(dilute);
	}

	public void removeRow(int index) {
		dilute.remove(index);
	}

	public void saveToTemplate(File file) throws IOException {
		FileOutputStream fos = new FileOutputStream(file);
		OutputStreamWriter bw = new OutputStreamWriter(fos, "UTF-8");
		//BufferedWriter bw = new BufferedWriter(osw);

		List<Dilution> db = new ArrayList<>(dilute);
		
		bw.write(Integer.toString(db.size()));
		bw.write(System.getProperty("line.separator"));
		for (int i = 0; i < db.size(); i++) {
			bw.write(db.get(i).getDilutionId() + "," + db.get(i).getPreviousDilution()+ "," + db.get(i).getSolutionQuantity()
					+ "," + db.get(i).getSolutionUnit()+ "," + db.get(i).getSolventQuantity()+ "," + db.get(i).getSolventUnit()
					+ "," + db.get(i).getCombiUnit());
			bw.write(System.getProperty("line.separator"));
		}

		bw.close();
		//osw.close();
		fos.close();
	}

	public void saveToFile(File file) throws IOException {
		FileOutputStream fos1 = new FileOutputStream(file);
		ObjectOutputStream oos1 = new ObjectOutputStream(fos1);

		Dilution[] dilution = dilute.toArray(new Dilution[dilute.size()]);

		oos1.writeObject(dilution);
		oos1.close();
	}

	public void loadFromFile(File file) throws IOException {
		FileInputStream fis1 = new FileInputStream(file);
		ObjectInputStream ois1 = new ObjectInputStream(fis1);

		try {
			Dilution[] dilution = (Dilution[]) ois1.readObject();

			dilute.clear();

			dilute.addAll(Arrays.asList(dilution));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ois1.close();
	}
}
