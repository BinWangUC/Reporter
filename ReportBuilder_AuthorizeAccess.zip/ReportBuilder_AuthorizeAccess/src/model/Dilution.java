package model;

import java.io.Serializable;

public class Dilution implements Serializable{
	private static final long serialVersionUID = 1096193905079036397L;
	
	private String dilutionId;
	private String previousDilution;
	private double solutionQuantity;
	private String solutionUnit;
	private double solventQuantity;
	private String solventUnit;
	private double concentration;
	private String combiUnit;
	
	public Dilution(String dilutionId, String previousDilution, double solutionQuantity, String solutionUnit,
			double solventQuantity, String solventUnit, double concentration, String combiUnit) {
		this.dilutionId = dilutionId;
		this.previousDilution= previousDilution;
		this.solutionQuantity= solutionQuantity;
		this.solutionUnit =solutionUnit;
		this.solventQuantity = solventQuantity;
		this.solventUnit = solventUnit;
		this.concentration = concentration;
		this.combiUnit = combiUnit;
		
	}
	
	public String getSolutionUnit() {
		return solutionUnit;
	}
	public String getSolventUnit() {
		return solventUnit;
	}
	public String getCombiUnit() {
		return combiUnit;
	}
	
	
	
	public String getDilutionId() {
		return dilutionId;
	}

	public void setDilutionId(String dilutionId) {
		this.dilutionId = dilutionId;
	}

	public String getPreviousDilution() {
		return previousDilution;
	}

	public void setPreviousDilution(String previousDilution) {
		this.previousDilution = previousDilution;
	}

	public double getSolutionQuantity() {
		return solutionQuantity;
	}

	public void setSolutionQuantity(double solutionQuantity) {
		this.solutionQuantity = solutionQuantity;
	}

	public double getSolventQuantity() {
		return solventQuantity;
	}

	public void setSolventQuantity(double solventQuantity) {
		this.solventQuantity = solventQuantity;
	}

	public double getConcentration() {
		return concentration;
	}

	public void setConcentration(double concentration) {
		this.concentration = concentration;
	}
	
}
