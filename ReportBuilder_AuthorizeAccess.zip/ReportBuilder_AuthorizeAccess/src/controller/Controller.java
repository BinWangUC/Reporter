
package controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import gui.FormEvent;
import gui.FormEvent1;
import model.Calibration;
import model.CalibrationData;
import model.Dilution;
import model.DilutionData;
import model.LinkDatabase;

public class Controller {
	DilutionData dbDilution = new DilutionData();
	CalibrationData dbCalibration = new CalibrationData();
	LinkDatabase lnk = new LinkDatabase();
	
	double resultCon;
	double concentration;
	
	public void connect() throws Exception {
		lnk.connect();
	}
	
	public void disconnect() {
		lnk.disconnect();
	}
	
	public void removeDilutionRow(int index) {
		dbDilution.removeRow(index);
	}

	public void removeCalibrationRow(int index) {
		dbCalibration.removeRow(index);
	}

	private List<Dilution> db = new ArrayList<>(dbDilution.getDilution());

	public List<Dilution> getDilution() {
		return dbDilution.getDilution();
	}

	public List<Calibration> getCalibration() {
		return dbCalibration.getCalibration();
	}

	public void addOriCocentration(double concentration) {
		Dilution dilution = new Dilution("0", "0", 100, "mL", 100, "mL", concentration / 1000, "mg/L");
		dbDilution.addDilution(dilution);
	}

	public void addDilution(FormEvent ev) {
		String Id = ev.getId();
		String PreviousId = ev.getPreviousId();
		double solutionQuantity = ev.getSolutionQuantity();
		String solutionUnit = ev.getSolutionUnit();
		double solventQuantity = ev.getSolventQuantity();
		String solventUnit = ev.getSolventUnit();
		String combiUnit = ev.getCombiUnit();

		db = new ArrayList<>(dbDilution.getDilution());
		for (int i = 0; i <= db.size() - 1; i++) {
			if (PreviousId.equals(db.get(i).getDilutionId())) {
				concentration = db.get(i).getConcentration();
				break;
			} else {
				concentration = 0;// or error
			}
		}

		concentrationCalcu(concentration, solventQuantity, solutionQuantity, solventUnit, solutionUnit, combiUnit);
		Dilution dilution = new Dilution(Id, PreviousId, solutionQuantity, solutionUnit, solventQuantity, solventUnit,
				resultCon, combiUnit);
		dbDilution.addDilution(dilution);

	}

	public void addCalibration(FormEvent1 ev1) {
		String calibrantId = ev1.getCalibrantId();
		String dilutionId = ev1.getDilutionId();
		double solutionQuantity = ev1.getSolutionQuantity();
		String solutionUnit = ev1.getSolutionUnit();
		double solventQuantity = ev1.getSolventQuantity();
		String solventUnit = ev1.getSolventUnit();
		String combiUnit = ev1.getCombiUnit();

		db = new ArrayList<>(dbDilution.getDilution());
		for (int i = 0; i <= db.size() - 1; i++) {
			if (dilutionId.equals(db.get(i).getDilutionId())) {
				concentration = db.get(i).getConcentration();
				break;
			} else {
				concentration = 0;// or error
			}
		}

		concentrationCalcu(concentration, solventQuantity, solutionQuantity, solventUnit, solutionUnit, combiUnit);
		Calibration calibration = new Calibration(calibrantId, dilutionId, solutionQuantity, solutionUnit,
				solventQuantity, solventUnit, resultCon, combiUnit);
		dbCalibration.addCalibration(calibration);
	}

	public void concentrationCalcu(double oCon, double sovQ, double solQ, String cUnit1, String cUnit2, String cCunit) {
		if (cUnit1.equals("mL"))
			sovQ = sovQ / 1000;
		if (cUnit1.equals("uL"))
			sovQ = sovQ / 1000000;
		if (cUnit2.equals("mL"))
			solQ = solQ / 1000;
		if (cUnit2.equals("uL"))
			solQ = solQ / 1000000;

		resultCon = oCon * solQ / sovQ;

	}

	public void saveDilutionToFile(File file) throws IOException {
		dbDilution.saveToFile(file);
	}

	public void loadDilutionFromFile(File file) throws IOException {
		dbDilution.loadFromFile(file);
	}

	public void saveCalibrationToFile(File file) throws IOException {
		dbCalibration.saveToFile(file);
	}

	public void loadCalibrationFromFile(File file) throws IOException {
		dbCalibration.loadFromFile(file);
	}
	
	public void exportDilutionToTemplate(File file) throws IOException {
		dbDilution.saveToTemplate(file);
	}

	public void exportCalibrationToTemplate(File file) throws IOException {
		dbCalibration.saveToTemplate(file);
	}
	
	public void importToTemplate(File file,JFrame parent) throws IOException{
		String oriConcern = JOptionPane.showInputDialog(parent, "Enter the original concentraion (mg/L).", "Original Solution ID",
				JOptionPane.OK_OPTION | JOptionPane.QUESTION_MESSAGE);

		Dilution dilution = new Dilution("0", "0", 1000, "mL", 1000, "mL", Double.valueOf(oriConcern) / 1000, "mg/L");
		dbDilution.addDilution(dilution);
		
		
		FileInputStream fis = new FileInputStream(file);
		InputStreamReader isr=new InputStreamReader(fis, "UTF-8");
        BufferedReader br = new BufferedReader(isr);
        String txt="";
        String[] arrs=null;
        int numOfDilution=Integer.valueOf(txt=br.readLine());
        int lines =0;
        while ((txt=br.readLine())!=null) {
        	lines++;
            arrs=txt.split(",");
            if (lines<=numOfDilution && lines>=2) {
        		String Id = arrs[0];
        		String PreviousId = arrs[1];
        		double solutionQuantity = Double.valueOf(arrs[2]);
        		String solutionUnit = arrs[3];
        		double solventQuantity = Double.valueOf(arrs[4]);
        		String solventUnit = arrs[5];
        		String combiUnit = arrs[6];
        		db = new ArrayList<>(dbDilution.getDilution());
        		for (int i = 0; i <= db.size() - 1; i++) {
        			if (PreviousId.equals(db.get(i).getDilutionId())) {
        				concentration = db.get(i).getConcentration();
        				break;
        			} else {
        				concentration = 0;// or error
        			}
        		}
            	concentrationCalcu(concentration, solventQuantity, solutionQuantity, solventUnit, solutionUnit, combiUnit);
        		Dilution dilution1 = new Dilution(Id, PreviousId, solutionQuantity, solutionUnit, solventQuantity, solventUnit,
        				resultCon, combiUnit);
        		dbDilution.addDilution(dilution1);
            }
            
            if ( lines>numOfDilution+1) {
            	String calibrantId = arrs[0];
        		String dilutionId = arrs[1];
        		double solutionQuantity = Double.valueOf(arrs[2]);
        		String solutionUnit = arrs[3];
        		double solventQuantity = Double.valueOf(arrs[4]);
        		String solventUnit = arrs[5];
        		String combiUnit = arrs[6];

        		db = new ArrayList<>(dbDilution.getDilution());
        		for (int i = 0; i <= db.size() - 1; i++) {
        			if (dilutionId.equals(db.get(i).getDilutionId())) {
        				concentration = db.get(i).getConcentration();
        				break;
        			} else {
        				concentration = 0;// or error
        			}
        		}

        		concentrationCalcu(concentration, solventQuantity, solutionQuantity, solventUnit, solutionUnit, combiUnit);
        		Calibration calibration = new Calibration(calibrantId, dilutionId, solutionQuantity, solutionUnit,
        				solventQuantity, solventUnit, resultCon, combiUnit);
        		dbCalibration.addCalibration(calibration);
            }
            
        }
        
        br.close();
        isr.close();
        fis.close();
	}


}
